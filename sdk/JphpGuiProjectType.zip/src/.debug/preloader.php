<?php

use facade\Json;
use php\format\JsonProcessor;
use php\framework\Logger;
use php\gui\framework\Application;
use php\gui\UXApplication;
use php\io\File;
use php\io\IOException;
use php\io\Stream;
use php\lang\ClassLoader;
use php\lang\Environment;
use php\lang\Module;
use php\lang\SourceMap;
use php\lib\fs;
use php\lib\str;
use php\time\Time;
use php\util\Scanner;
use php\util\SharedValue;

try {
    Stream::putContents("application.pid", UXApplication::getPid());
} catch (IOException $e) {
    exit(1);
}

Logger::setLevel(Logger::LEVEL_DEBUG);
